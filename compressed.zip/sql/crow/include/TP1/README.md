# sistemaBancario
Projeto de Sistema Bancário para disciplina de programação orientada a objetos

Variaveis -> 1a Letra minuscula (ex.: variavelA)
Classes -> 1a Letra maiuscula (ex.: Cliente)
Funcoes -> 1a Letra maiuscula(ex.:CreditarValor)
