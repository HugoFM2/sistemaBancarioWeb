#include "Banco.h"
#include "Cliente.h"
#include <bits/stdc++.h>

class WebInterface{
public:
  void CadastrarCliente(Banco* Banco, std::string nomeCliente, std::string cpf_cnpj, std::string endereco, std::string fone);
};
